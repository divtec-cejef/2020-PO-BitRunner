﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EndGame : MonoBehaviour
{
    // Si le personnage entre en collision avec un obstacle ou un bonus
    void OnTriggerEnter(Collider col)
    {
        GameObject player = GameObject.Find("Player");

        // Diminue la vitesse du personnage quand il rentre dans un obstacle
        if (col.gameObject.tag == "Finish")
        {

            SceneManager.LoadScene("Outro");
        }
    }
}
