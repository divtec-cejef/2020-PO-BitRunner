﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomSpawner : MonoBehaviour
{
    public Transform[] spawnPoints;
    public GameObject[] enemyPrefabs;
    public int nbrSpawn = 10;
    void Start()
    {

    }

    void Update()
    {
        if (nbrSpawn >= 0)
        {
            int randEnemy = Random.Range(0, enemyPrefabs.Length);
            int randSpawPoint = Random.Range(0, spawnPoints.Length);

            if (spawnPoints[randSpawPoint].position)
            Instantiate(enemyPrefabs[randEnemy], spawnPoints[randSpawPoint].position, transform.rotation);
            nbrSpawn -= 1;
        }
    }
}
