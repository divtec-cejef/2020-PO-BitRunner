﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomSpawner : MonoBehaviour
{
    public Transform[] spawnPoints;
    public GameObject[] enemyPrefabs;

    // nombre d'objets à apparaître
    public int nbrSpawn = 10;
    void Start()
    {

    }

    void Update()
    {
        // Apparition des bonus/malus
        if (nbrSpawn >= 0)
        {
            int randEnemy = Random.Range(0, enemyPrefabs.Length);
            int randSpawPoint = Random.Range(0, spawnPoints.Length);

            Instantiate(enemyPrefabs[randEnemy], spawnPoints[randSpawPoint].position, transform.rotation);
            nbrSpawn -= 1;
        }
    }
}
