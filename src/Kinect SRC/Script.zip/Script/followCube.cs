﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Security.Cryptography;
using UnityEngine;

public class followCube : MonoBehaviour
{
    public const float squat = 0.5f;
    public const float stand = 1.0f;
    public const float delay = 1.0f;

    [Range(-2, 2)] public float valueX;
    public GameObject kinectCube;
    public GameObject playerCube;
    public float Speed = 10f;
    
    public float gravity = 20f;
    private CharacterController controller;

    public float jumpSpeed = 8.0f;
    private Vector3 Jump = Vector3.zero;

    // Start is called before the first frame update
    void Start()
    {
        Jump = transform.forward;
        Jump = transform.TransformDirection(Jump);
        Jump *= Speed;

        controller = GetComponent<CharacterController>();
        kinectCube.transform.position = new Vector3(0, 0, 0);
    }

    void FixedUpdate()
    {
        playerCube.transform.position = new Vector3(valueX, transform.position.y, transform.position.z);
        transform.Translate(Vector3.forward * Time.deltaTime * Speed);
    }
    
    // Update is called once per frame
    void LateUpdate()
    {

        // Défini la gravité et le mouvement du personnage
        Jump.y -= gravity * Time.deltaTime;
        controller.Move(Jump * Time.deltaTime);

        //Saut
        if (kinectCube.transform.position.y >= 3 && controller.isGrounded && transform.localScale.y == stand)
        {
            Jump.y = jumpSpeed;
            StartCoroutine(ExecuteAfterTime(delay));
            return;
        }

        //S'accroupir
        if (kinectCube.transform.position.y <= -4 && controller.isGrounded)
        {
            transform.localScale = new Vector3(transform.localScale.x, squat, transform.localScale.z);
            StartCoroutine(ExecuteAfterTime(delay));
            return;
        }

        //Ligne droite
        if (kinectCube.transform.position.x >= 3)
        {
            if (valueX == 2)
                return;
            valueX += 2;

        }

        //Ligne gauche
        if (kinectCube.transform.position.x <= -3)
        {
            if (valueX == -2)
                return;
            valueX -= 2;
        }
        
        //Ligne centrale
        if (kinectCube.transform.position.x <= 1 && kinectCube.transform.position.x >= -1)
        {
            if (valueX == 2 || valueX == -2)
            {
                valueX = 0;
                return;
            }
                
        }
        
    }

    // Permet d'effectuer du code après un délai
    IEnumerator ExecuteAfterTime(float time)
    {
        yield return new WaitForSeconds(time);
        transform.localScale = new Vector3(transform.localScale.x, stand, transform.localScale.z);
    }
}
